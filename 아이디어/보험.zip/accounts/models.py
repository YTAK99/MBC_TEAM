from django.contrib.auth.models import AbstractUser
from django.db import models


class CustomUser(AbstractUser):
    class Role(models.TextChoices):
        STUDENT    = "student",    "학생"
        TA         = "ta",         "조교"
        INSTRUCTOR = "instructor", "강사"

    role = models.CharField(
        max_length=20,
        choices=Role.choices,
        default=Role.STUDENT,
    )

    def get_role_display_style(self):
        """템플릿에서 뱃지 스타일을 바로 꺼내 쓸 수 있도록"""
        styles = {
            "instructor": {"label": "강사", "bg": "#1A1A2E", "color": "#F5F3EE"},
            "ta":         {"label": "조교", "bg": "#FF5C35", "color": "#fff"},
            "student":    {"label": "학생", "bg": "#EDEAE3", "color": "#1A1A2E"},
        }
        return styles.get(self.role, styles["student"])

    def __str__(self):
        return f"{self.username} ({self.get_role_display()})"
