from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import CustomUser


class SignupForm(UserCreationForm):
    email = forms.EmailField(required=True, label="이메일")

    class Meta:
        model = CustomUser
        fields = ("username", "email", "password1", "password2", "role")
        labels = {
            "username": "아이디",
            "role": "역할",
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # 필드별 placeholder
        self.fields["username"].widget.attrs.update({"placeholder": "사용할 아이디"})
        self.fields["email"].widget.attrs.update({"placeholder": "이메일 주소"})
        self.fields["password1"].widget.attrs.update({"placeholder": "비밀번호"})
        self.fields["password2"].widget.attrs.update({"placeholder": "비밀번호 확인"})
        # 도움말 텍스트 제거
        for field in self.fields.values():
            field.help_text = None


class LoginForm(AuthenticationForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["username"].widget.attrs.update({"placeholder": "아이디 입력"})
        self.fields["password"].widget.attrs.update({"placeholder": "비밀번호 입력"})
        self.fields["username"].label = "아이디"
