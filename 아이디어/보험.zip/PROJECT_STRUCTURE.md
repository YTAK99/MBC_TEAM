# ClassQ — Django 전환 가이드

## 디렉토리 구조

```
classq/                          ← 프로젝트 루트
├── manage.py
├── requirements.txt
├── .env.example
│
├── classq/                      ← 프로젝트 설정 패키지
│   ├── __init__.py
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py
│
├── questions/                   ← 핵심 앱 (질문/답변)
│   ├── __init__.py
│   ├── models.py                ← Tag, Question, Answer 모델
│   ├── views.py                 ← CBV 기반 뷰
│   ├── urls.py
│   ├── forms.py                 ← QuestionForm, AnswerForm
│   ├── serializers.py           ← DRF용 (선택)
│   └── admin.py
│
├── accounts/                    ← 인증 앱
│   ├── __init__.py
│   ├── models.py                ← CustomUser (role 포함)
│   ├── views.py
│   ├── urls.py
│   └── forms.py
│
├── templates/
│   ├── base.html                ← 공통 레이아웃 (사이드바, 탑바)
│   ├── questions/
│   │   ├── home.html
│   │   ├── board.html
│   │   ├── detail.html
│   │   └── ask.html
│   └── registration/
│       ├── login.html
│       └── signup.html
│
└── static/
    └── css/
        └── theme.css            ← 기존 theme.css 그대로 사용
```

## 기술 스택

| 구성 요소 | 선택 | 이유 |
|-----------|------|------|
| 백엔드 | Django 5.x | |
| 인증 | django.contrib.auth + AbstractUser | role 필드 추가 |
| DB | SQLite (개발) / PostgreSQL (배포) | |
| 프론트엔드 | Django Templates + Tailwind CDN | 기존 스타일 유지 |
| API (선택) | Django REST Framework | React 연동 시 |

## 앱 분리 전략

- **questions** — 질문, 답변, 태그, 좋아요 (핵심 도메인)
- **accounts** — 회원가입/로그인, CustomUser (role: student/ta/instructor)
- **classq** — 프로젝트 설정

## 주요 URL 구조

```
/                    → home
/board/              → 질문 목록 (필터, 정렬, 검색)
/board/<id>/         → 질문 상세 + 답변
/ask/                → 질문 등록
/accounts/login/     → 로그인
/accounts/signup/    → 회원가입
/accounts/logout/    → 로그아웃

# API (DRF 선택 시)
/api/questions/
/api/questions/<id>/like/
/api/questions/<id>/resolve/
```
