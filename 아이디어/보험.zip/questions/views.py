from django.shortcuts import get_object_or_404, redirect
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import TemplateView, ListView, DetailView, CreateView
from django.views import View
from django.urls import reverse_lazy, reverse
from django.http import JsonResponse
from django.db.models import Q, Count

from .models import Question, Tag, Like
from .forms import QuestionForm, AnswerForm


class HomeView(TemplateView):
    template_name = "questions/home.html"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["total"]    = Question.objects.count()
        ctx["resolved"] = Question.objects.filter(is_resolved=True).count()
        ctx["pending"]  = Question.objects.filter(is_resolved=False).count()
        ctx["recent"]   = Question.objects.prefetch_related("tags")[:3]
        return ctx


class BoardView(ListView):
    model = Question
    template_name = "questions/board.html"
    context_object_name = "questions"
    paginate_by = 20

    def get_queryset(self):
        qs = Question.objects.prefetch_related("tags", "likes", "answers").annotate(
            answer_count=Count("answers"),
        )
        # 검색
        q = self.request.GET.get("q", "").strip()
        if q:
            qs = qs.filter(Q(title__icontains=q) | Q(content__icontains=q))
        # 태그 필터
        tag_id = self.request.GET.get("tag")
        if tag_id:
            qs = qs.filter(tags__id=tag_id)
        # 정렬
        sort = self.request.GET.get("sort", "recent")
        if sort == "likes":
            qs = qs.annotate(lc=Count("likes")).order_by("-lc")
        else:
            qs = qs.order_by("-created_at")
        return qs

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["tags"]       = Tag.objects.all()
        ctx["active_tag"] = self.request.GET.get("tag")
        ctx["sort"]       = self.request.GET.get("sort", "recent")
        ctx["search_q"]   = self.request.GET.get("q", "")
        # 현재 유저가 좋아요한 질문 id 집합
        if self.request.user.is_authenticated:
            ctx["liked_ids"] = set(
                Like.objects.filter(user=self.request.user).values_list("question_id", flat=True)
            )
        else:
            ctx["liked_ids"] = set()
        return ctx


class QuestionDetailView(DetailView):
    model = Question
    template_name = "questions/detail.html"
    context_object_name = "question"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["answer_form"] = AnswerForm()
        ctx["answers"] = self.object.answers.select_related("author").all()
        if self.request.user.is_authenticated:
            ctx["user_liked"] = Like.objects.filter(
                user=self.request.user, question=self.object
            ).exists()
        else:
            ctx["user_liked"] = False
        return ctx

    def post(self, request, *args, **kwargs):
        """답변 등록"""
        if not request.user.is_authenticated:
            return redirect("login")
        question = self.get_object()
        form = AnswerForm(request.POST)
        if form.is_valid():
            answer = form.save(commit=False)
            answer.question = question
            answer.author   = request.user
            answer.save()
        return redirect("questions:detail", pk=question.pk)


class AskView(LoginRequiredMixin, CreateView):
    form_class = QuestionForm
    template_name = "questions/ask.html"
    login_url = "login"

    def form_valid(self, form):
        question = form.save(commit=False)
        question.author = self.request.user
        question.save()
        form.save_m2m()
        return redirect("questions:detail", pk=question.pk)

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["all_tags"] = Tag.objects.all()
        return ctx


class LikeToggleView(LoginRequiredMixin, View):
    """POST /questions/<pk>/like/ → JSON {liked, count}"""
    login_url = "login"

    def post(self, request, pk):
        question = get_object_or_404(Question, pk=pk)
        like, created = Like.objects.get_or_create(user=request.user, question=question)
        if not created:
            like.delete()
            liked = False
        else:
            liked = True
        return JsonResponse({"liked": liked, "count": question.like_count})


class ResolveView(LoginRequiredMixin, View):
    """POST /questions/<pk>/resolve/ — 작성자만 가능"""
    login_url = "login"

    def post(self, request, pk):
        question = get_object_or_404(Question, pk=pk, author=request.user)
        question.is_resolved = True
        question.save(update_fields=["is_resolved"])
        return redirect("questions:detail", pk=pk)
