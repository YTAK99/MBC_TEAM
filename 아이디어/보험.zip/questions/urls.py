from django.urls import path
from . import views

app_name = "questions"

urlpatterns = [
    path("",              views.HomeView.as_view(),          name="home"),
    path("board/",        views.BoardView.as_view(),         name="board"),
    path("board/<int:pk>/", views.QuestionDetailView.as_view(), name="detail"),
    path("ask/",          views.AskView.as_view(),           name="ask"),
    path("board/<int:pk>/like/",    views.LikeToggleView.as_view(), name="like"),
    path("board/<int:pk>/resolve/", views.ResolveView.as_view(),    name="resolve"),
]
