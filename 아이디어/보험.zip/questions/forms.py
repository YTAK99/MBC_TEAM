from django import forms
from .models import Question, Answer, Tag


class QuestionForm(forms.ModelForm):
    tags = forms.ModelMultipleChoiceField(
        queryset=Tag.objects.all(),
        widget=forms.CheckboxSelectMultiple,
        required=False,
        label="태그 (최대 3개)",
    )

    class Meta:
        model = Question
        fields = ("title", "content", "tags", "is_anonymous")
        labels = {
            "title": "제목",
            "content": "내용",
            "is_anonymous": "익명으로 올리기",
        }
        widgets = {
            "title": forms.TextInput(attrs={
                "placeholder": "질문 제목을 간결하게 적어주세요",
                "class": "input-field",
            }),
            "content": forms.Textarea(attrs={
                "placeholder": "어떤 부분이 헷갈리는지 구체적으로 설명해주세요",
                "rows": 5,
                "class": "input-field resize-none",
            }),
        }

    def clean_tags(self):
        tags = self.cleaned_data.get("tags")
        if tags and tags.count() > 3:
            raise forms.ValidationError("태그는 최대 3개까지 선택할 수 있습니다.")
        return tags


class AnswerForm(forms.ModelForm):
    class Meta:
        model = Answer
        fields = ("content",)
        labels = {"content": ""}
        widgets = {
            "content": forms.Textarea(attrs={
                "placeholder": "답변을 입력해주세요...",
                "rows": 3,
                "class": "input-field resize-none",
            }),
        }
