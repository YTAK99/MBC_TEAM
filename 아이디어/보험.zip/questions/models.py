from django.db import models
from django.conf import settings


class Tag(models.Model):
    name  = models.CharField(max_length=50, unique=True)
    color = models.CharField(max_length=7, default="#6B7280")  # hex

    def __str__(self):
        return self.name


class Question(models.Model):
    author      = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="questions",
    )
    title       = models.CharField(max_length=200)
    content     = models.TextField()
    is_anonymous = models.BooleanField(default=True)
    is_resolved  = models.BooleanField(default=False)
    tags        = models.ManyToManyField(Tag, blank=True, related_name="questions")
    created_at  = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    # 좋아요 수 — annotate 또는 프로퍼티 중 선택
    @property
    def like_count(self):
        return self.likes.count()

    def display_author(self):
        return "익명" if self.is_anonymous else self.author.username

    def __str__(self):
        return self.title


class Answer(models.Model):
    question   = models.ForeignKey(Question, on_delete=models.CASCADE, related_name="answers")
    author     = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="answers",
    )
    content    = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["created_at"]

    def __str__(self):
        return f"Answer by {self.author} on {self.question}"


class Like(models.Model):
    """질문 좋아요 (1인 1회)"""
    user     = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    question = models.ForeignKey(Question, on_delete=models.CASCADE, related_name="likes")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("user", "question")
