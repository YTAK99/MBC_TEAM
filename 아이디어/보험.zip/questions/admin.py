from django.contrib import admin
from .models import Tag, Question, Answer, Like


@admin.register(Tag)
class TagAdmin(admin.ModelAdmin):
    list_display = ("name", "color")


@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display  = ("title", "author", "is_anonymous", "is_resolved", "like_count", "created_at")
    list_filter   = ("is_resolved", "is_anonymous", "tags")
    search_fields = ("title", "content")
    filter_horizontal = ("tags",)


@admin.register(Answer)
class AnswerAdmin(admin.ModelAdmin):
    list_display = ("question", "author", "created_at")


@admin.register(Like)
class LikeAdmin(admin.ModelAdmin):
    list_display = ("user", "question", "created_at")
