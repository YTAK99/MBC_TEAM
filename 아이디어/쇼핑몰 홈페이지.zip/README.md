
  # 쇼핑몰 홈페이지

  This is a code bundle for 쇼핑몰 홈페이지. The original project is available at https://www.figma.com/design/KjqiE6GSNlbblw2YKrcPEz/%EC%87%BC%ED%95%91%EB%AA%B0-%ED%99%88%ED%8E%98%EC%9D%B4%EC%A7%80.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  