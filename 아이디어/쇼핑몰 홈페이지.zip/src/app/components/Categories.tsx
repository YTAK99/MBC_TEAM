export function Categories() {
  const categories = [
    {
      name: '여성 의류',
      image: 'https://images.unsplash.com/photo-1656504450814-398cf348c038?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=600',
    },
    {
      name: '남성 의류',
      image: 'https://images.unsplash.com/photo-1617178388553-a9d022974a5c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=600',
    },
    {
      name: '액세서리',
      image: 'https://images.unsplash.com/photo-1620777888789-0ee95b57a277?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=600',
    },
  ];

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <h3 className="text-3xl font-bold mb-8">카테고리</h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {categories.map((category) => (
          <div
            key={category.name}
            className="relative h-64 rounded-lg overflow-hidden cursor-pointer group"
          >
            <img
              src={category.image}
              alt={category.name}
              className="w-full h-full object-cover group-hover:scale-110 transition duration-300"
            />
            <div className="absolute inset-0 bg-black bg-opacity-20 group-hover:bg-opacity-30 transition flex items-end">
              <h4 className="text-white text-2xl font-bold p-6">{category.name}</h4>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
