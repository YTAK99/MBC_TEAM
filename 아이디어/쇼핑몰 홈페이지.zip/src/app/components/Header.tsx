import { Search, ShoppingCart, User, Menu } from 'lucide-react';

export function Header() {
  return (
    <header className="sticky top-0 z-50 bg-white border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-8">
            <button className="lg:hidden">
              <Menu className="w-6 h-6" />
            </button>
            <h1 className="text-2xl font-bold">SHOP</h1>
            <nav className="hidden lg:flex gap-6">
              <a href="#" className="text-gray-700 hover:text-gray-900">여성</a>
              <a href="#" className="text-gray-700 hover:text-gray-900">남성</a>
              <a href="#" className="text-gray-700 hover:text-gray-900">액세서리</a>
              <a href="#" className="text-gray-700 hover:text-gray-900">세일</a>
            </nav>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-2 bg-gray-100 px-4 py-2 rounded-full">
              <Search className="w-4 h-4 text-gray-500" />
              <input
                type="text"
                placeholder="검색"
                className="bg-transparent outline-none w-48"
              />
            </div>
            <button className="md:hidden">
              <Search className="w-5 h-5" />
            </button>
            <button className="relative">
              <ShoppingCart className="w-5 h-5" />
              <span className="absolute -top-2 -right-2 bg-black text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                3
              </span>
            </button>
            <button>
              <User className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
