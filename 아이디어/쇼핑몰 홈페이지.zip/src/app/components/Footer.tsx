import { Instagram, Facebook, Twitter } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h4 className="text-white text-lg font-bold mb-4">고객 서비스</h4>
            <ul className="space-y-2">
              <li><a href="#" className="hover:text-white">배송 안내</a></li>
              <li><a href="#" className="hover:text-white">반품/교환</a></li>
              <li><a href="#" className="hover:text-white">FAQ</a></li>
              <li><a href="#" className="hover:text-white">고객센터</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white text-lg font-bold mb-4">쇼핑 정보</h4>
            <ul className="space-y-2">
              <li><a href="#" className="hover:text-white">회원혜택</a></li>
              <li><a href="#" className="hover:text-white">이벤트</a></li>
              <li><a href="#" className="hover:text-white">쿠폰</a></li>
              <li><a href="#" className="hover:text-white">적립금</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white text-lg font-bold mb-4">회사 정보</h4>
            <ul className="space-y-2">
              <li><a href="#" className="hover:text-white">회사소개</a></li>
              <li><a href="#" className="hover:text-white">채용정보</a></li>
              <li><a href="#" className="hover:text-white">이용약관</a></li>
              <li><a href="#" className="hover:text-white">개인정보처리방침</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white text-lg font-bold mb-4">팔로우</h4>
            <div className="flex gap-4">
              <a href="#" className="hover:text-white">
                <Instagram className="w-6 h-6" />
              </a>
              <a href="#" className="hover:text-white">
                <Facebook className="w-6 h-6" />
              </a>
              <a href="#" className="hover:text-white">
                <Twitter className="w-6 h-6" />
              </a>
            </div>
            <div className="mt-6">
              <p className="text-sm mb-2">뉴스레터 구독</p>
              <div className="flex">
                <input
                  type="email"
                  placeholder="이메일 주소"
                  className="bg-gray-800 px-4 py-2 rounded-l-lg outline-none flex-1"
                />
                <button className="bg-white text-black px-4 py-2 rounded-r-lg hover:bg-gray-100">
                  구독
                </button>
              </div>
            </div>
          </div>
        </div>
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm">
          <p>© 2026 SHOP. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
