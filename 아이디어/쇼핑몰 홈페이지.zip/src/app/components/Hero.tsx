export function Hero() {
  return (
    <section className="relative h-[500px] bg-gradient-to-r from-gray-100 to-gray-200">
      <img
        src="https://images.unsplash.com/photo-1655576751811-ec945b9e023e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1920"
        alt="Hero"
        className="w-full h-full object-cover"
      />
      <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center">
        <div className="text-center text-white">
          <h2 className="text-5xl font-bold mb-4">2026 봄 컬렉션</h2>
          <p className="text-xl mb-8">새로운 시즌, 새로운 스타일</p>
          <button className="bg-white text-black px-8 py-3 rounded-full hover:bg-gray-100 transition">
            지금 쇼핑하기
          </button>
        </div>
      </div>
    </section>
  );
}
