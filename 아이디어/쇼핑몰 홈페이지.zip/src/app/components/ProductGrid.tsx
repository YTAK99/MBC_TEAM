import { Heart } from 'lucide-react';

export function ProductGrid() {
  const products = [
    {
      id: 1,
      name: '클래식 화이트 셔츠',
      price: '89,000',
      image: 'https://images.unsplash.com/photo-1539278383962-a7774385fa02?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=600',
      tag: 'NEW',
    },
    {
      id: 2,
      name: '데님 팬츠',
      price: '129,000',
      image: 'https://images.unsplash.com/photo-1617178388553-a9d022974a5c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=600',
      tag: 'BEST',
    },
    {
      id: 3,
      name: '여름 드레스',
      price: '159,000',
      image: 'https://images.unsplash.com/photo-1655576751811-ec945b9e023e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=600',
      tag: 'SALE',
    },
    {
      id: 4,
      name: '베이지 드레스',
      price: '139,000',
      image: 'https://images.unsplash.com/photo-1620777888789-0ee95b57a277?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=600',
    },
    {
      id: 5,
      name: '스프링 원피스',
      price: '179,000',
      image: 'https://images.unsplash.com/photo-1656504450814-398cf348c038?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=600',
      tag: 'NEW',
    },
    {
      id: 6,
      name: '쇼핑백 세트',
      price: '45,000',
      image: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=600',
    },
  ];

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 bg-gray-50">
      <div className="flex justify-between items-center mb-8">
        <h3 className="text-3xl font-bold">인기 상품</h3>
        <button className="text-gray-700 hover:text-gray-900">전체보기 →</button>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {products.map((product) => (
          <div key={product.id} className="group cursor-pointer">
            <div className="relative mb-4 overflow-hidden rounded-lg bg-white">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-80 object-cover group-hover:scale-105 transition duration-300"
              />
              {product.tag && (
                <span className="absolute top-4 left-4 bg-black text-white px-3 py-1 text-sm">
                  {product.tag}
                </span>
              )}
              <button className="absolute top-4 right-4 bg-white rounded-full p-2 opacity-0 group-hover:opacity-100 transition">
                <Heart className="w-5 h-5" />
              </button>
            </div>
            <h4 className="text-lg mb-2">{product.name}</h4>
            <p className="font-bold">{product.price}원</p>
          </div>
        ))}
      </div>
    </section>
  );
}
